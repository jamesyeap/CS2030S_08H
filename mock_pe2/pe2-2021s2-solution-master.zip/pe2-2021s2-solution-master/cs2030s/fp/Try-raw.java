package cs2030s.fp;

public abstract class Try<T> {

  public static <T> Try<T> failure(Throwable msg) {
    return new Failure<T>(msg);
  }

  public static <T> Try<T> success(T value) {
    return new Success<T>(value);
  }

  public static Try of(Producer producer) {
    try {
      return success(producer.produce());
    } catch (Throwable e) {
      return failure(e);
    }
  }

  abstract public T get() throws Throwable;
  abstract public <R> Try<R> map(Transformer mapper);
  abstract public <R> Try<R> flatMap(Transformer mapper);
  abstract public Try<T> onFailure(Consumer consumer);
  abstract public Try<T> recover(Transformer transformer);

  static class Success<T> extends Try<T> {
    T value;
    Success(T value) {
      this.value = value;
    }

    public String toString() {
      return "Success: " + String.valueOf(value);
    }

    public Try map(Transformer mapper) {
      try {
        return success(mapper.transform(value));
      } catch (Throwable e) {
        return failure(e);
      }
    }

    public <R> Try<R> flatMap(Transformer mapper) {
      @SuppressWarnings("unchecked")
      Try<R> t =  (Try<R>) mapper.transform(value);
      return t;
    }

    public T get() throws Throwable {
      return value;
    }

    public Try<T> onFailure(Consumer consumer) {
      return this;
    }

    public Try<T> recover(Transformer transformer) {
      return this;
    }

    public boolean equals(Object o) {
      if (o != null && o instanceof Success) {
        Success<?> success = (Success<?>) o;
        if (success.value != null) {
          return success.value.equals(this.value);
        } else 
          return this.value == null;
      }
      return false;
    }
  }

  static class Failure<T> extends Try<T> {
    Throwable throwable;
    Failure(Throwable value) {
      this.throwable = value;
    }

    public String toString() {
      return "Failure: " + String.valueOf(throwable);
    }

    public <R> Failure<R> map(Transformer mapper) {
      @SuppressWarnings("unchecked")
      Failure<R> t =  (Failure<R>) this;
      return t;
    }

    public <R> Failure<R> flatMap(Transformer mapper) {
      @SuppressWarnings("unchecked")
      Failure<R> t =  (Failure<R>) this;
      return t;
    }

    public T get() throws Throwable {
      throw throwable;
    }

    public Try<T> onFailure(Consumer consumer) {
      try {
        consumer.consume(this.throwable);
        return this;
      } catch (Throwable t) {
        return failure(t);
      }
    }

    public Try recover(Transformer transformer) {
      try {
        return success(transformer.transform(this.throwable));
      } catch (Throwable t) {
        return failure(t);
      }
    }

    public boolean equals(Object o) {
      if (o != null && o instanceof Failure) {
        Failure<?> that = (Failure<?>) o;
        return that.throwable.toString().equals(this.throwable.toString());
      }
      return false;
    }
  }
}
